var playButton = document.getElementsByClassName("playButton")[0]
var stopButton = document.getElementsByClassName("stopButton")[0]

playButton.addEventListener("click",function(){
	var audio=document.getElementsByTagName("audio")[0]
	audio.play()

})


stopButton.addEventListener("click",function(){
	var audio=document.getElementsByTagName("audio")[0]
	audio.pause()

})